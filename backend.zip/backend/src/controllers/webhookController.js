const Bill = require("../models/Bill");
const PaymentLink = require("../models/PaymentLink");
const Transaction = require("../models/Transaction");
const WebhookEvent = require("../models/WebhookEvent");

async function cashfreeWebhook(req, res) {
  try {
    const event = req.body;
    const headers = req.headers;

    console.log("➡️ Cashfree Webhook Received:", event.type);

    // 1. Always log raw webhook
    await WebhookEvent.create({
      type: event.type,
      raw_payload: JSON.stringify(event),
      headers: JSON.stringify(headers),
      verified: true, // TODO: add signature verification later
      status: "RECEIVED",
      received_at: new Date(),
    });

    // 2. Handle Payment Success
    if (
      event.type === "PAYMENT_SUCCESS_WEBHOOK" ||
      event.type === "payment.success"
    ) {
      const cfLinkId = event.data?.order?.order_tags?.cf_link_id;
      const cfPaymentId = event.data?.payment?.cf_payment_id;
      const amount = event.data?.payment?.payment_amount;
      const currency = event.data?.payment?.payment_currency;
      const bankRef = event.data?.payment?.bank_reference;

      // find PaymentLink
      const payLink = await PaymentLink.findOne({ where: { cf_link_id: cfLinkId } });

      if (payLink) {
        // update bill
        const bill = await Bill.findByPk(payLink.bill_id);
        if (bill) {
          bill.status = "PAID";
          bill.bank_ref = bankRef;
          await bill.save();
          console.log(`✅ Bill ${bill.bill_number} marked as PAID`);
        }

        // update payment link status
        payLink.status = "PAID";
        await payLink.save();

        // create transaction log
        await Transaction.create({
          bill_id: payLink.bill_id,
          cf_payment_id: cfPaymentId,
          amount,
          currency,
          status: "SUCCESS",
          bank_ref: bankRef,
          paid_at: new Date(event.data?.payment?.payment_time),
        });
      }
    }

    res.json({ received: true });
  } catch (err) {
    console.error("❌ Webhook error:", err.message);
    if (err.stack) console.error(err.stack);
    res.status(500).json({ error: err.message });
  }
}

module.exports = { cashfreeWebhook };
