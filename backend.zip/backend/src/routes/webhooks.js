const express = require("express");
const { cashfreeWebhook } = require("../controllers/webhookController");

const router = express.Router();

router.post("/", cashfreeWebhook);

module.exports = router;
